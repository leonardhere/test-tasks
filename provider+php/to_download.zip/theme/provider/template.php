<!DOCTYPE html>
<html lang="ru">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no, maximum-scale=1">
	<title>Главная</title>
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,400i,700,700i" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Lato:400,400i,700,700i" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="<?php get_theme_url(); ?>/css/normalize.css" />
	<link rel="stylesheet" type="text/css" href="<?php get_theme_url(); ?>/css/icomoon.css">
	<link rel="stylesheet" type="text/css" href="<?php get_theme_url(); ?>/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="<?php get_theme_url(); ?>/css/slick.css">
	<link rel="stylesheet" type="text/css" href="<?php get_theme_url(); ?>/css/style.css" />
	<link rel="stylesheet" type="text/css" href="<?php get_theme_url(); ?>/css/modal_style.css" />
	<link rel="stylesheet" type="text/css" href="<?php get_theme_url(); ?>/css/animate.css" />
	<link rel="stylesheet" type="text/css" href="<?php get_theme_url(); ?>/css/customs_for_animations.css" />

</head>
<body>

<header>
	<div class="wrapper">
		<div class="header-wrap">
			<div class="logo"><a href="#"></a></div>
			<nav class="navigation">
				<button class="menu-toggle">
					<span></span>
					<span></span>
					<span></span>
				</button>
				<ul class="menu">
					<li class="menu__item">
						<a href="#stream" class="menu__link">О компании</a>
					</li>
					<li class="menu__item">
						<a href="#rates" class="menu__link">Тарифы</a>
					</li>
					<li class="menu__item">
						<a href="#contacts" class="menu__link">Контакты</a>
					</li>
					<li class="menu__item">
						<a href="#" class="menu__link menu_lk cd-signin">Личный кабинет</a>
					</li>
					
				</ul>
			</nav>
		</div>
	</div>
</header>
<div class="cd-user-modal"> <!-- все формы на фоне затемнения-->
	<div class="cd-user-modal-container"> <!-- основной контейнер -->
		<ul class="cd-switcher">
			<li><a href="#0">Вход</a></li>
		</ul>

		<div id="cd-login"> <!-- форма входа -->
			<form class="cd-form">
				<p class="fieldset">
					<label class="image-replace cd-email" for="signin-email">Номер договора</label>
					<input class="full-width has-padding has-border" id="signin-email" type="email" placeholder="Номер договора">
					<span class="cd-error-message">Здесь сообщение об ошибке!</span>
				</p>

				<p class="fieldset">
					<label class="image-replace cd-password" for="signin-password">Пароль</label>
					<input class="full-width has-padding has-border" id="signin-password" type="password"  placeholder="Пароль">
					<span class="cd-error-message">Здесь сообщение об ошибке!</span>
				</p>
				<p class="fieldset">
					<input class="full-width" type="submit" value="Войти">
				</p>
			</form>
		</div> <!-- cd-login -->
	</div> <!-- cd-user-modal-container -->
</div> <!-- cd-user-modal -->

<section class="banner">
	<div class="banner-container">
		<div class="banner-slider">
			<div class="slideone">
				<div class="slide-content">
					<div class="textbanner">
						<h1 class="">Быстрый интернет
							<span class="lg">Дома / В офисе / На даче</span>
							
						</h1>
					</div>
					<a href="#contacts" class="btnnew">Подключиться</a>
					<div class="slide-image"></div>
				</div>
			</div>
			<div class="slidetwo">
				<div class="slide-content">
					<div class="textbanner">
						<h1>Тарифы для юридических лиц
							<span class="lg">Выгодная цена  / Стабильность  / Гибкие  условия</span>
						</h1>
					</div>
					<a href="#contacts" class="btnnew">Подключиться</a>
					<div class="slide-image"></div>
				</div>
			</div>
		</div>
	</div>
</section>
<div class="scrollup">
  <i class="fa fa-chevron-up"></i>
</div>
<section class="about section">
	<div class="wrapper">
		<div class="heading" id="stream">
			<h2>Компания СТРИМ</h2>
			<p>Интернет-провайдер "СТРИМ" предоставляет услуги по организации постоянного доступа в интернет по выделенным каналам связи частным лицам, коммерческим организациям и государственным предприятиям. В рамках этого проекта компания построила свою собственную волоконно-оптическую сеть. Сеть "СТРИМ" создана с использованием решений ведущих производителей сетевого оборудования по технологии GigabitEthernet. Благодаря качественной телекоммуникационной инфраструктуре сети, пользователи получают доступ к большому количеству ресурсов и сервисов сети, а также к ресурсам сетей других операторов связи.</p>
		</div>
		<div class="about-wrap">
			<div class="about-wrap-content">
				<div class="about-wrap-content__icon animated">
					<img src="<?php get_theme_url(); ?>/img/fiz_face.png" alt="fiz">
				</div>
				<div class="about-wrap-content__text">
					<h6>Интернет для физических лиц</h6>

					<p>Ведущим направлением нашей работы являются подключение к Интернет физических лиц. Качественная и скоростная связь по оптоволоконным каналам позволяет абонентам нашей сети не использовать телефонную линию и обмениваться через интернет любыми объемами данных.</p>
 
				</div>
			</div>
		</div>
		<div class="about-wrap">
			<div class="about-wrap-content">

				<div class="about-wrap-content__icon animated">
					<img src="<?php get_theme_url(); ?>/img/ur_face.png" alt="ur">
				</div>

				<div class="about-wrap-content__text">
					<h6>Интернет для юридических лиц</h6>
					<p>Наша компания предлагает подключение к Интернет по волоконно-оптическим выделенным линиям, строительство корпоративных сетей, подключение офисов и многое другое.</p>
				</div>
			</div>
		</div>
		
		<div class="hr"></div>

		<div class="box-pricing-new" id="rates">
			<div class="service-list__item">
				<div class="about-wrap-content__icon animated">
					<span class="fa fa-building"></span>
				</div>
				<h6>Подключение по технологии Ethernet в многоквартирных домах:</h6>
				<p>- Обязательным условием подключения, повторного подключения к Услуге по технологии Ethernet, является внесение денежных средств в размере не менее 1500 рублей на Лицевой счет в течение трех календарных дней после подключения. - Плата взимается за входящий трафик Интернет. Трафик ко всем ресурсам сети ООО «Стрим» не тарифицируется. - Активация услуги «Драйв» производится Абонентом самостоятельно через Личный кабинет, либо с помощью техподдержки Оператора. Автоматическое снижение скорости до значения, определяемого действующим тарифным планом, происходит через 24 часа с момента активации. Заказ услуги возможен при наличии более 15 рублей на Лицевом счете Абонента. - Добровольная блокировка- Оператор предоставляет право Абоненту воспользоваться данной услугой не чаще чем два раза в год. </p>
			</div>

			<div class="pricing">
				<div class="pricing__item">
					<div class="pricing-header">
						<span class="pricing-header__title">
						 Домашний <br>Лайт <span>800 руб.</span> 
						</span>
					</div>
					<ul class="pricing-list">
						<li>Скорость: до 15 Мбит/c</li>
						<li>«Драйв» (увеличение скорости до 60 мбит/с), разовый платеж - 15 руб.</li>
						<li>Добровольная блокировка: Бесплатно</li>
					</ul>
				</div>
				<div class="pricing__item">
					<div class="pricing-header">
						<span class="pricing-header__title">
						 Домашний <br>Экстра <span>1000 руб.</span> 
						</span>

					</div>
					<ul class="pricing-list">
						<li>Скорость: до 30 Мбит/c</li>
						<li>«Драйв» (увеличение скорости до 60 мбит/с), разовый платеж - 15 руб.</li>
						<li>Добровольная блокировка: Бесплатно</li>
					</ul>
				</div>
				<div class="pricing__item active">
					<div class="pricing-header">
						<span class="pricing-header__title">
						  Домашний <br> Профи <span>1500 руб.</span> 
						</span>
					</div>

					<ul class="pricing-list">
						<li>Скорость: до 60 Мбит/c</li>
						<li>«Драйв» (увеличение скорости до 60 мбит/с), разовый платеж —</li>
						<li>Добровольная блокировка: Бесплатно</li>
					</ul>
				</div>
			</div>
		</div>
		<div class="box-pricing-new">
			<div class="service-list__item">
				<div class="about-wrap-content__icon animated">
					<span class="fa fa-home"></span>
				</div>
				<h6>Подключение по технологии Ethernet частного сектора</h6>
				<p>- Плата взимается за входящий трафик Интернет. Трафик ко всем ресурсам сети ООО «Стрим» не тарифицируется.
- Активация услуги «Драйв» производится Абонентом самостоятельно через Личный кабинет, либо с помощью техподдержки Оператора. Автоматическое снижение скорости до значения, определяемого действующим тарифным планом, происходит через 24 часа с момента активации. Заказ услуги возможен при наличии более 15 рублей на Лицевом счете Абонента.

- Стоимость подключения уточняется в службе технической поддержки.

- Добровольная блокировка- Оператор предоставляет право Абоненту воспользоваться данной услугой не чаще чем два раза в год. </p>
			</div>

			<div class="pricing" id="fourblock">
				<div class="pricing__item">
					<div class="pricing-header">
						<span class="pricing-header__title">
						 Загородный <br> Оптима <span>800 руб.</span> 
						</span>
					</div>
					<ul class="pricing-list">
						<li>Скорость: до 15 Мбит/c</li>
						<li>«Драйв» (увеличение скорости до 60 мбит/с), разовый платеж - 15 руб.</li>
						<li>Добровольная блокировка: Бесплатно</li>
					</ul>
				</div>
				<div class="pricing__item">
					<div class="pricing-header">
						<span class="pricing-header__title">
						 Загородный <br> Лайт <span>1000 руб.</span> 
						</span>
					</div>
					<ul class="pricing-list">
						<li>Скорость: до 30 Мбит/c</li>
						<li>«Драйв» (увеличение скорости до 60 мбит/с), разовый платеж - 15 руб.</li>
						<li>Добровольная блокировка: Бесплатно</li>
					</ul>
				</div>
				<div class="pricing__item">
					<div class="pricing-header">
						<span class="pricing-header__title">
						 Загородный <br> Профи <span>1500 руб.</span> 
						</span>

					</div>
					<ul class="pricing-list">
						<li>Скорость: до 60 Мбит/c</li>
						<li>«Драйв» (увеличение скорости до 60 мбит/с), разовый платеж — </li>
						<li>Добровольная блокировка: Бесплатно</li>
					</ul>
				</div>
				<div class="pricing__item active">
					<div class="pricing-header">
						<span class="pricing-header__title">
						 Загородный Максимум <span>2000 руб.</span> 
						</span>
					</div>

					<ul class="pricing-list">
						<li>Скорость: до 100 Мбит/c</li>
						<li>«Драйв» (увеличение скорости до 60 мбит/с), разовый платеж — </li>
						<li>Добровольная блокировка: Бесплатно</li>
					</ul>
				</div>
			</div>
		</div>
		<div class="box-pricing-new">
			<div class="service-list__item">
				<div class="about-wrap-content__icon animated">
					<span class="fa fa-wifi"></span>
				</div>
				<h6>Подключение по технологии Wi-Fi:</h6>
				<p>- Плата взимается за входящий трафик Интернет. Трафик ко всем ресурсам сети ООО «Стрим» не тарифицируется.
- Активация услуги «Драйв» производится Абонентом самостоятельно через Личный кабинет, либо с помощью техподдержки Оператора. Автоматическое снижение скорости до значения, определяемого действующим тарифным планом, происходит через 24 часа с момента активации. Заказ услуги возможен при наличии более 15 рублей на Лицевом счете Абонента.

- Стоимость подключения от 5000 руб. Устанавливается Оператором после уточнения технической возможности подключения по адресу Абонента.

- Добровольная блокировка- Оператор предоставляет право Абоненту воспользоваться данной услугой не чаще чем два раза в год.</p>
			</div>

			<div class="pricing">
				<div class="pricing__item">
					<div class="pricing-header">
						<span class="pricing-header__title">
						 Wi-fi Neo <span>800 руб.</span> 
						</span>
					</div>
					<ul class="pricing-list">
						<li>Скорость: до 10 Мбит/c</li>
						<li>Добровольная блокировка: бесплатно</li>
					</ul>
				</div>
				<div class="pricing__item">
					<div class="pricing-header">
						<span class="pricing-header__title">
						 Wi-fi Extra <span>1000 руб.</span> 
						</span>

					</div>
					<ul class="pricing-list">
						<li>Скорость: до 20 Мбит/c</li>
						<li>Добровольная блокировка: бесплатно</li>
					</ul>
				</div>
				<div class="pricing__item active">
					<div class="pricing-header">
						<span class="pricing-header__title">
						 Wi-fi Profi <span>1500 руб.</span> 
						</span>
					</div>
						<ul class="pricing-list">
						<li>Скорость: до 30 Мбит/c</li>
						<li>Добровольная блокировка: бесплатно</li>
					</ul>
				</div>
			</div>
		</div>
		<div class="hr"></div>
	</div>
</section>


<section class="section contact" id="contacts">
	<div class="wrapper">
		<div class="contact-wrap">
			
			<div class="contact-wrap__right">
				<h6>Контактная информация</h6>
				<p>Общество с ограниченной ответственностью «Стрим» <br>
Юридический адрес: 141290, Московская обл. г. Красноармейск, ул. Лермонтова, дом 2. <br>

ОГРН: 1155038003614 ИНН/КПП: 5038113725/503801001 <br>

Банковские реквизиты в ВТБ 24 ПАО г. Москва. <br> Расчетный счет 407 028 104 000 000 47 498 <br> Корреспондентский счет 301 018 101 000 000 00 716 БИК 044 525 716</p>
				<ul class="contact-list">
					<li class="contact-list__item">
						<span class="contact-list__icon"><i class="fa fa-map-marker" aria-hidden="true"></i></span>
						<span>Московская обл. г. Красноармейск, ул. Лермонтова, дом 2.</span>
					</li>
					<li class="contact-list__item">
						<span class="contact-list__icon"><i class="fa fa-phone" aria-hidden="true"></i></span>
						<a href="tel:6131468728">8-926-641-33-11, </a> <a href="tel:6109876543">8-926-964-04-65</a>
					</li>
					<li class="contact-list__item">
						<span class="contact-list__icon"><i class="fa fa-envelope" aria-hidden="true"></i></span>
						<a href="mailto:support@envato.net">support@envato.net</a>
					</li>
				</ul>
			</div>
	
	<div id="map" class="animated">
	<iframe src="https://yandex.ru/map-widget/v1/?um=constructor%3A7bcaaa6a781e2efcbb19ea778fae82d250e5edae36e29b792286d7ee7bf9b3ce&amp;source=constructor" width="450" height="400" ></iframe>
</div>
		</div>
	</div>
		<div id="mapnew" class="animated">
			<iframe src="https://yandex.ru/map-widget/v1/?um=constructor%3A7bcaaa6a781e2efcbb19ea778fae82d250e5edae36e29b792286d7ee7bf9b3ce&amp;source=constructor" ></iframe>
		</div>
</section>



<footer class="footer">
	<div class="wrapper footer-flex">
		<p class="copyright">&copy; Стрим 2018. Все права защищены</p>
	</div>
</footer>
<script src="<?php get_theme_url(); ?>/js/jquery-1.11.0.min.js"></script>
<script src="<?php get_theme_url(); ?>/js/slick.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?v=3&key=AIzaSyAFqPKNORR3Ctvc2Rzj8YX5oebd7xpSGVs"></script>
<script src="<?php get_theme_url(); ?>/js/custom.js"></script>

<script  src="<?php get_theme_url(); ?>/js/modal.js"></script>
<script src="<?php get_theme_url(); ?>/js/jquery.waypoints.min.js"></script>
<script src="<?php get_theme_url(); ?>/js/customs_for_animations.js"></script>
<script>
$(function() {

  $('.scrollup').click(function() {
    $("html, body").animate({
      scrollTop:0
    },1000);
  })
})

$(window).scroll(function() {
  if ($(this).scrollTop()>200) {
    $('.scrollup').fadeIn();
  }
  else {
    $('.scrollup').fadeOut();
  }
});
</script>
</body>
</html>